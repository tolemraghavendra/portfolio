import { CheckCircle2, AlertTriangle, XCircle, ArrowRight } from 'lucide-react'

const STATUS_ICON = {
  SUCCESS: { Icon: CheckCircle2, classes: 'text-emerald-500' },
  WARNING: { Icon: AlertTriangle, classes: 'text-amber-500' },
  ERROR: { Icon: XCircle, classes: 'text-rose-500' },
  RUNNING: { Icon: ArrowRight, classes: 'text-brand-500' },
}

function formatTime(ts) {
  try {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  } catch {
    return ''
  }
}

export default function AgentActivityItem({ agent, action, status = 'SUCCESS', timestamp }) {
  const { Icon, classes } = STATUS_ICON[status] || STATUS_ICON.SUCCESS
  return (
    <div className="flex items-start gap-3 py-2.5">
      <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${classes}`} strokeWidth={2.25} />
      <div className="min-w-0 flex-1">
        <p className="text-sm text-slate-700">
          <span className="font-semibold text-slate-900">{agent}</span> — {action}
        </p>
        {timestamp && <p className="mt-0.5 text-xs text-slate-400">{formatTime(timestamp)}</p>}
      </div>
    </div>
  )
}
