const CONFIG = {
  High: 'bg-rose-50 text-rose-700 border-rose-200',
  Medium: 'bg-sky-50 text-sky-700 border-sky-200',
  Low: 'bg-slate-100 text-slate-600 border-slate-200',
}

export default function PriorityBadge({ priority }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${CONFIG[priority] || CONFIG.Medium}`}>
      {priority}
    </span>
  )
}
