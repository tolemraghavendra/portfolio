import { CheckCircle2, AlertTriangle, XCircle, Circle } from 'lucide-react'

const CONFIG = {
  EXPLICIT: { label: 'Explicit', classes: 'bg-emerald-50 text-emerald-700 border-emerald-200', Icon: CheckCircle2 },
  UNCLEAR: { label: 'Unclear', classes: 'bg-amber-50 text-amber-700 border-amber-200', Icon: AlertTriangle },
  NOT_FOUND: { label: 'Not Found', classes: 'bg-slate-100 text-slate-500 border-slate-200', Icon: XCircle },
  PENDING: { label: 'Pending', classes: 'bg-brand-50 text-brand-700 border-brand-200', Icon: Circle },
}

export default function StatusBadge({ status, size = 'md' }) {
  const cfg = CONFIG[status] || CONFIG.NOT_FOUND
  const { Icon } = cfg
  const pad = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${pad} ${cfg.classes}`}>
      <Icon className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} strokeWidth={2.5} />
      {cfg.label}
    </span>
  )
}
