import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, FilePlus2, Users, ScrollText, Sparkles, ChevronRight,
} from 'lucide-react'

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/jobs/new', label: 'Create Job', icon: FilePlus2 },
  { to: '/audit', label: 'Audit Trail', icon: ScrollText },
]

export default function Layout({ children, title, breadcrumb }) {
  const navigate = useNavigate()
  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-50 text-slate-900">
      <aside className="flex w-64 shrink-0 flex-col border-r border-slate-200 bg-white">
        <div className="flex items-center gap-2 px-6 py-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-600">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <p className="text-base font-bold leading-none text-slate-900">HireFlow</p>
            <p className="mt-0.5 text-[11px] leading-none text-slate-400">Evidence-Based Hiring</p>
          </div>
        </div>

        <nav className="mt-2 flex-1 space-y-1 px-3">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-brand-50 text-brand-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`
              }
            >
              <Icon className="h-4.5 w-4.5" strokeWidth={2} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-slate-100 p-4">
          <div className="rounded-lg bg-slate-50 p-3">
            <p className="text-xs font-semibold text-slate-700">Human-in-the-loop</p>
            <p className="mt-1 text-[11px] leading-snug text-slate-500">
              HireFlow surfaces evidence and interview intelligence. Final hiring decisions remain
              with the human recruiter.
            </p>
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-8">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            {breadcrumb && (
              <>
                <button onClick={() => navigate(-1)} className="hover:text-slate-700">
                  {breadcrumb}
                </button>
                <ChevronRight className="h-3.5 w-3.5" />
              </>
            )}
            <span className="font-semibold text-slate-900">{title}</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Agents Active
            </div>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
              R
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto px-8 py-7">{children}</main>
      </div>
    </div>
  )
}
