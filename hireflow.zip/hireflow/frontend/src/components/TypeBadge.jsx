export default function TypeBadge({ type }) {
  const isRequired = type === 'Required'
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${
        isRequired ? 'bg-brand-50 text-brand-700 border-brand-200' : 'bg-slate-50 text-slate-600 border-slate-200'
      }`}
    >
      {type}
    </span>
  )
}
