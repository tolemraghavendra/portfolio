import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// Normalize backend error shape ({ detail: "..." }) into a plain Error with a readable message.
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const detail = err?.response?.data?.detail
    const message = detail || err.message || 'Something went wrong. Please try again.'
    return Promise.reject(new Error(message))
  }
)

export const RolesAPI = {
  list: () => api.get('/roles').then((r) => r.data),
  create: (title, description) => api.post('/roles', { title, description }).then((r) => r.data),
  get: (roleId) => api.get(`/roles/${roleId}`).then((r) => r.data),
  analyze: (roleId) => api.post(`/roles/${roleId}/analyze`).then((r) => r.data),
  candidates: (roleId) => api.get(`/roles/${roleId}/candidates`).then((r) => r.data),
}

export const CandidatesAPI = {
  upload: (formData) =>
    api
      .post('/candidates/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } })
      .then((r) => r.data),
  get: (candidateId) => api.get(`/candidates/${candidateId}`).then((r) => r.data),
  evidence: (candidateId) => api.get(`/candidates/${candidateId}/evidence`).then((r) => r.data),
  audit: (candidateId) => api.get(`/candidates/${candidateId}/audit`).then((r) => r.data),
}

export const InterviewAPI = {
  validate: (candidateId, requirementId) =>
    api.post(`/candidates/${candidateId}/validate`, { requirement_id: requirementId }).then((r) => r.data),
  analyze: (candidateId, interviewId, answer) =>
    api
      .post(`/candidates/${candidateId}/interview/analyze`, { interview_id: interviewId, answer })
      .then((r) => r.data),
}

export const AuditAPI = {
  global: () => api.get('/audit').then((r) => r.data),
}

export const DashboardAPI = {
  stats: () => api.get('/dashboard/stats').then((r) => r.data),
}

export default api
