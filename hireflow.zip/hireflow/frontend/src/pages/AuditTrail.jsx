import { useEffect, useState } from 'react'
import { ScrollText } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { Card } from '../components/Card.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import Loading from '../components/Loading.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import EmptyState from '../components/EmptyState.jsx'
import { AuditAPI } from '../services/api.js'

const AGENT_DOT = {
  'JD Analyzer': 'bg-sky-500',
  'Resume Analyzer': 'bg-violet-500',
  'Evidence Mapper': 'bg-amber-500',
  'Validation Agent': 'bg-orange-500',
  'Interview Agent': 'bg-emerald-500',
  System: 'bg-slate-400',
}

function formatTimestamp(ts) {
  try {
    return new Date(ts).toLocaleString([], {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit',
    })
  } catch {
    return ts
  }
}

export default function AuditTrail() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    AuditAPI.global()
      .then(setLogs)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  return (
    <Layout title="Audit Trail" breadcrumb="Dashboard">
      <div className="mb-6">
        <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight text-slate-900">
          <ScrollText className="h-5 w-5 text-slate-400" /> Audit Trail
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          Every AI agent action across every job role and candidate, in order.
        </p>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? (
        <Loading label="Loading audit trail…" />
      ) : logs.length === 0 ? (
        <EmptyState icon={ScrollText} title="No agent activity yet" description="Create a job and analyze a candidate to see the full audit trail." />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-3">Timestamp</th>
                <th className="px-5 py-3">Agent</th>
                <th className="px-5 py-3">Action</th>
                <th className="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/60">
                  <td className="whitespace-nowrap px-5 py-3.5 font-mono text-xs text-slate-400">
                    {formatTimestamp(log.timestamp)}
                  </td>
                  <td className="whitespace-nowrap px-5 py-3.5">
                    <span className="flex items-center gap-2 font-medium text-slate-800">
                      <span className={`h-1.5 w-1.5 rounded-full ${AGENT_DOT[log.agent] || 'bg-slate-400'}`} />
                      {log.agent}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-slate-600">{log.action}</td>
                  <td className="px-5 py-3.5">
                    <StatusBadge
                      status={log.status === 'ERROR' ? 'NOT_FOUND' : log.status === 'WARNING' ? 'UNCLEAR' : 'EXPLICIT'}
                      size="sm"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </Layout>
  )
}
