import { useEffect, useState } from 'react'
import { useParams, useLocation, useNavigate } from 'react-router-dom'
import { HelpCircle, Loader2, Sparkles, ArrowLeft, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { Card } from '../components/Card.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import Loading from '../components/Loading.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import { InterviewAPI } from '../services/api.js'

const RESULT_ICON = { EXPLICIT: CheckCircle2, UNCLEAR: AlertTriangle, NOT_FOUND: XCircle }
const RESULT_TONE = {
  EXPLICIT: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  UNCLEAR: 'bg-amber-50 text-amber-700 border-amber-200',
  NOT_FOUND: 'bg-slate-100 text-slate-600 border-slate-200',
}

export default function InterviewIntelligence() {
  const { candidateId, requirementId } = useParams()
  const location = useLocation()
  const navigate = useNavigate()

  const [interviewData, setInterviewData] = useState(location.state || null)
  const [loadingQuestion, setLoadingQuestion] = useState(!location.state)
  const [answer, setAnswer] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    if (interviewData) return
    setLoadingQuestion(true)
    InterviewAPI.validate(candidateId, requirementId)
      .then((res) =>
        setInterviewData({
          interviewId: res.interview_id,
          requirementSkill: res.requirement_skill,
          reason: res.reason,
          question: res.question,
        })
      )
      .catch((e) => setError(e.message))
      .finally(() => setLoadingQuestion(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function handleAnalyze(e) {
    e.preventDefault()
    if (!answer.trim()) {
      setError('Please enter the candidate\u2019s answer before analyzing.')
      return
    }
    setAnalyzing(true)
    setError('')
    try {
      const res = await InterviewAPI.analyze(candidateId, interviewData.interviewId, answer.trim())
      setResult(res)
    } catch (err) {
      setError(err.message)
    } finally {
      setAnalyzing(false)
    }
  }

  if (loadingQuestion) {
    return (
      <Layout title="Interview Intelligence" breadcrumb="Candidate">
        <Loading label="Generating targeted interview question…" />
      </Layout>
    )
  }

  if (!interviewData) {
    return (
      <Layout title="Interview Intelligence" breadcrumb="Candidate">
        <ErrorBanner message={error || 'Could not load this validation question.'} />
      </Layout>
    )
  }

  const ResultIcon = result ? RESULT_ICON[result.status] : null

  return (
    <Layout title="Interview Intelligence" breadcrumb="Candidate">
      <div className="mx-auto max-w-2xl">
        <button
          onClick={() => navigate(`/candidates/${candidateId}`)}
          className="mb-5 flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-700"
        >
          <ArrowLeft className="h-4 w-4" /> Back to candidate
        </button>

        <ErrorBanner message={error} onDismiss={() => setError('')} />

        <Card className="mb-5 p-6">
          <div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-brand-600">
            <HelpCircle className="h-3.5 w-3.5" /> Requirement Being Validated
          </div>
          <h1 className="text-xl font-bold text-slate-900">{interviewData.requirementSkill}</h1>

          <div className="mt-4 rounded-lg bg-slate-50 p-4">
            <p className="text-xs font-semibold text-slate-500">Why Validation Is Needed</p>
            <p className="mt-1 text-sm text-slate-700">{interviewData.reason}</p>
          </div>

          <div className="mt-4 rounded-lg border border-brand-100 bg-brand-50 p-4">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-brand-700">
              <Sparkles className="h-3.5 w-3.5" /> AI-Generated Question
            </p>
            <p className="mt-1.5 text-sm font-medium text-slate-800">{interviewData.question}</p>
          </div>
        </Card>

        <Card className="p-6">
          <form onSubmit={handleAnalyze} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Candidate Answer</label>
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                rows={6}
                placeholder="Type or paste the candidate's answer here…"
                className="w-full resize-none rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>
            <button
              type="submit"
              disabled={analyzing}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {analyzing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Analyzing Answer…
                </>
              ) : (
                'Analyze Answer'
              )}
            </button>
          </form>

          {result && (
            <div className={`mt-5 rounded-lg border p-4 ${RESULT_TONE[result.status]}`}>
              <div className="flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide">
                  <ResultIcon className="h-3.5 w-3.5" /> AI Evidence Analysis
                </p>
                <StatusBadge status={result.status} size="sm" />
              </div>
              <p className="mt-2 text-sm">{result.evidence}</p>
              <p className="mt-2 text-xs opacity-70">Confidence: {Math.round(result.confidence * 100)}%</p>
              <button
                onClick={() => navigate(`/candidates/${candidateId}`)}
                className="mt-4 rounded-lg border border-current px-3.5 py-2 text-xs font-semibold hover:opacity-80"
              >
                View Updated Evidence Table
              </button>
            </div>
          )}
        </Card>
      </div>
    </Layout>
  )
}
