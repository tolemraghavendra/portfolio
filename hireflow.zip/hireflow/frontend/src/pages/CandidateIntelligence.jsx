import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { CheckCircle2, AlertTriangle, XCircle, ScrollText, MessageCircleQuestion, Loader2 } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { Card } from '../components/Card.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import Loading from '../components/Loading.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import { CandidatesAPI, InterviewAPI } from '../services/api.js'

export default function CandidateIntelligence() {
  const { candidateId } = useParams()
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [validatingId, setValidatingId] = useState(null)

  function load() {
    setLoading(true)
    CandidatesAPI.get(candidateId)
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }

  useEffect(load, [candidateId])

  async function handleValidate(requirementId) {
    setValidatingId(requirementId)
    setError('')
    try {
      const result = await InterviewAPI.validate(candidateId, requirementId)
      navigate(`/candidates/${candidateId}/interview/${requirementId}`, {
        state: {
          interviewId: result.interview_id,
          requirementSkill: result.requirement_skill,
          reason: result.reason,
          question: result.question,
        },
      })
    } catch (err) {
      setError(err.message)
      setValidatingId(null)
    }
  }

  if (loading) {
    return (
      <Layout title="Candidate Intelligence" breadcrumb="Dashboard">
        <Loading label="Loading candidate…" />
      </Layout>
    )
  }
  if (!data) {
    return (
      <Layout title="Candidate Intelligence" breadcrumb="Dashboard">
        <ErrorBanner message={error || 'Candidate not found.'} />
      </Layout>
    )
  }

  const { candidate, role_title, evidence, summary } = data

  return (
    <Layout title={candidate.name} breadcrumb="Dashboard">
      <ErrorBanner message={error} onDismiss={() => setError('')} />

      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">{candidate.name}</h1>
          <p className="mt-1 text-sm text-slate-500">
            {candidate.email} · Applying for <span className="font-medium text-slate-700">{role_title}</span>
          </p>
        </div>
        <button
          onClick={() => navigate('/audit')}
          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
        >
          <ScrollText className="h-4 w-4" /> View Audit Trail
        </button>
      </div>

      <div className="mb-6 grid grid-cols-3 gap-4">
        <Card className="flex items-center gap-3 p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="h-4.5 w-4.5" />
          </div>
          <div>
            <p className="text-xl font-bold text-slate-900">{summary.confirmed}</p>
            <p className="text-xs text-slate-500">Confirmed</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
            <AlertTriangle className="h-4.5 w-4.5" />
          </div>
          <div>
            <p className="text-xl font-bold text-slate-900">{summary.needs_validation}</p>
            <p className="text-xs text-slate-500">Needs Validation</p>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
            <XCircle className="h-4.5 w-4.5" />
          </div>
          <div>
            <p className="text-xl font-bold text-slate-900">{summary.not_found}</p>
            <p className="text-xs text-slate-500">Not Found</p>
          </div>
        </Card>
      </div>

      <h2 className="mb-3 text-base font-semibold text-slate-900">Evidence Table</h2>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="border-b border-slate-100 bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-5 py-3">Requirement</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3">Evidence</th>
              <th className="px-5 py-3">Source</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {evidence.map((e) => (
              <tr key={e.id} className="hover:bg-slate-50/60">
                <td className="px-5 py-3.5 font-medium text-slate-900">{e.requirement_skill}</td>
                <td className="px-5 py-3.5"><StatusBadge status={e.status} /></td>
                <td className="max-w-sm px-5 py-3.5 text-slate-600">{e.evidence_text}</td>
                <td className="px-5 py-3.5 font-mono text-xs text-slate-400">{e.source_page || '\u2014'}</td>
                <td className="px-5 py-3.5 text-right">
                  {e.status !== 'EXPLICIT' && (
                    <button
                      onClick={() => handleValidate(e.requirement_id)}
                      disabled={validatingId === e.requirement_id}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-brand-200 bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100 disabled:opacity-60"
                    >
                      {validatingId === e.requirement_id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <MessageCircleQuestion className="h-3.5 w-3.5" />
                      )}
                      Validate
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </Layout>
  )
}
