import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Briefcase, Users, ShieldAlert, Clock3, Plus, ArrowRight, Activity } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { StatCard, Card } from '../components/Card.jsx'
import Loading from '../components/Loading.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import EmptyState from '../components/EmptyState.jsx'
import AgentActivityItem from '../components/AgentActivityItem.jsx'
import { DashboardAPI, RolesAPI } from '../services/api.js'

export default function Dashboard() {
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)
  const [roles, setRoles] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let mounted = true
    Promise.all([DashboardAPI.stats(), RolesAPI.list()])
      .then(([s, r]) => {
        if (!mounted) return
        setStats(s)
        setRoles(r)
      })
      .catch((e) => mounted && setError(e.message))
      .finally(() => mounted && setLoading(false))
    return () => {
      mounted = false
    }
  }, [])

  return (
    <Layout title="Dashboard">
      <ErrorBanner message={error} onDismiss={() => setError('')} />

      {loading ? (
        <Loading label="Loading dashboard…" />
      ) : (
        <>
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">Welcome back</h1>
              <p className="mt-1 text-sm text-slate-500">
                From resume screening to evidence-based interviews.
              </p>
            </div>
            <button
              onClick={() => navigate('/jobs/new')}
              className="flex items-center gap-2 rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-brand-700"
            >
              <Plus className="h-4 w-4" /> Create Job
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Total Job Roles" value={stats.total_roles} icon={Briefcase} tone="brand" />
            <StatCard label="Total Candidates" value={stats.total_candidates} icon={Users} tone="slate" />
            <StatCard label="Needs Validation" value={stats.needs_validation} icon={ShieldAlert} tone="amber" />
            <StatCard label="Pending Review" value={stats.pending_review} icon={Clock3} tone="emerald" />
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-base font-semibold text-slate-900">Active Roles</h2>
              </div>
              {roles.length === 0 ? (
                <EmptyState
                  icon={Briefcase}
                  title="No job roles yet"
                  description="Create your first job role to start the agentic evidence-validation workflow."
                  action={
                    <button
                      onClick={() => navigate('/jobs/new')}
                      className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
                    >
                      Create Job
                    </button>
                  }
                />
              ) : (
                <div className="space-y-3">
                  {roles.map((role) => (
                    <Card
                      key={role.id}
                      className="cursor-pointer p-5 transition-shadow hover:shadow-md"
                    >
                      <button onClick={() => navigate(`/jobs/${role.id}`)} className="flex w-full items-center justify-between text-left">
                        <div>
                          <p className="font-semibold text-slate-900">{role.title}</p>
                          <p className="mt-1 text-xs text-slate-400">
                            {role.requirements.length} requirements · Created{' '}
                            {new Date(role.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <ArrowRight className="h-4 w-4 text-slate-300" />
                      </button>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            <div>
              <div className="mb-3 flex items-center gap-2">
                <Activity className="h-4 w-4 text-slate-400" />
                <h2 className="text-base font-semibold text-slate-900">AI Activity</h2>
              </div>
              <Card className="max-h-[420px] divide-y divide-slate-100 overflow-y-auto p-4">
                {stats.recent_activity.length === 0 ? (
                  <p className="py-6 text-center text-sm text-slate-400">No agent activity yet.</p>
                ) : (
                  stats.recent_activity.map((item) => (
                    <AgentActivityItem
                      key={item.id}
                      agent={item.agent}
                      action={item.action}
                      status={item.status}
                      timestamp={item.timestamp}
                    />
                  ))
                )}
              </Card>
            </div>
          </div>
        </>
      )}
    </Layout>
  )
}
