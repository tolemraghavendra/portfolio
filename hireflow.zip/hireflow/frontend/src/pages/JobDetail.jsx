import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { UploadCloud, Loader2, Users, FileText, ArrowRight } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { Card } from '../components/Card.jsx'
import PriorityBadge from '../components/PriorityBadge.jsx'
import TypeBadge from '../components/TypeBadge.jsx'
import Loading from '../components/Loading.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import EmptyState from '../components/EmptyState.jsx'
import { RolesAPI, CandidatesAPI } from '../services/api.js'

export default function JobDetail() {
  const { roleId } = useParams()
  const navigate = useNavigate()
  const [role, setRole] = useState(null)
  const [candidates, setCandidates] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)

  function load() {
    setLoading(true)
    Promise.all([RolesAPI.get(roleId), RolesAPI.candidates(roleId)])
      .then(([r, c]) => {
        setRole(r)
        setCandidates(c)
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }

  useEffect(load, [roleId])

  async function handleUpload(e) {
    e.preventDefault()
    if (!name.trim() || !email.trim() || !file) {
      setError('Please provide candidate name, email, and a resume file.')
      return
    }
    setUploading(true)
    setError('')
    try {
      const formData = new FormData()
      formData.append('role_id', roleId)
      formData.append('name', name.trim())
      formData.append('email', email.trim())
      formData.append('resume', file)
      const result = await CandidatesAPI.upload(formData)
      navigate(`/candidates/${result.candidate.id}`)
    } catch (err) {
      setError(err.message)
      setUploading(false)
    }
  }

  if (loading) {
    return (
      <Layout title="Job Role" breadcrumb="Dashboard">
        <Loading label="Loading job role…" />
      </Layout>
    )
  }

  if (!role) {
    return (
      <Layout title="Job Role" breadcrumb="Dashboard">
        <ErrorBanner message={error || 'Job role not found.'} />
      </Layout>
    )
  }

  return (
    <Layout title={role.title} breadcrumb="Dashboard">
      <ErrorBanner message={error} onDismiss={() => setError('')} />

      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{role.title}</h1>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-500">{role.description}</p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <h2 className="mb-3 text-base font-semibold text-slate-900">Extracted Requirements</h2>
          <Card className="overflow-hidden">
            {role.requirements.length === 0 ? (
              <EmptyState icon={FileText} title="No requirements extracted yet" />
            ) : (
              <table className="w-full text-sm">
                <thead className="border-b border-slate-100 bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-5 py-3">Requirement</th>
                    <th className="px-5 py-3">Type</th>
                    <th className="px-5 py-3">Priority</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {role.requirements.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-50/60">
                      <td className="px-5 py-3.5">
                        <p className="font-medium text-slate-900">{req.skill}</p>
                        <p className="mt-0.5 text-xs text-slate-400">{req.description}</p>
                      </td>
                      <td className="px-5 py-3.5"><TypeBadge type={req.type} /></td>
                      <td className="px-5 py-3.5"><PriorityBadge priority={req.priority} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>

          <h2 className="mb-3 mt-8 flex items-center gap-2 text-base font-semibold text-slate-900">
            <Users className="h-4 w-4 text-slate-400" /> Candidates
          </h2>
          {candidates.length === 0 ? (
            <EmptyState icon={Users} title="No candidates yet" description="Upload a resume to run the agentic analysis pipeline." />
          ) : (
            <div className="space-y-3">
              {candidates.map((c) => (
                <Card key={c.id} className="cursor-pointer p-4 transition-shadow hover:shadow-md">
                  <button onClick={() => navigate(`/candidates/${c.id}`)} className="flex w-full items-center justify-between text-left">
                    <div>
                      <p className="font-semibold text-slate-900">{c.name}</p>
                      <p className="text-xs text-slate-400">{c.email}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-300" />
                  </button>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-2">
          <h2 className="mb-3 text-base font-semibold text-slate-900">Analyze Candidate</h2>
          <Card className="p-5">
            {role.requirements.length === 0 ? (
              <p className="text-sm text-slate-400">Analyze the job description first to enable candidate uploads.</p>
            ) : (
              <form onSubmit={handleUpload} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-slate-700">Candidate Name</label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="candidate@example.com"
                    className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-slate-700">Resume (PDF, DOCX, or TXT)</label>
                  <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-200 px-4 py-8 text-center hover:border-brand-300 hover:bg-brand-50/30">
                    <UploadCloud className="mb-2 h-6 w-6 text-slate-400" />
                    <span className="text-sm font-medium text-slate-600">
                      {file ? file.name : 'Click to select a resume'}
                    </span>
                    <span className="mt-1 text-xs text-slate-400">.pdf, .docx, .txt</span>
                    <input
                      type="file"
                      accept=".pdf,.docx,.txt"
                      className="hidden"
                      onChange={(e) => setFile(e.target.files?.[0] || null)}
                    />
                  </label>
                </div>
                <button
                  type="submit"
                  disabled={uploading}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {uploading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Analyzing Candidate…
                    </>
                  ) : (
                    'Analyze Candidate'
                  )}
                </button>
              </form>
            )}
          </Card>
        </div>
      </div>
    </Layout>
  )
}
