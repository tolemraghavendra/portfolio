import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Sparkles, Loader2 } from 'lucide-react'
import Layout from '../components/Layout.jsx'
import { Card } from '../components/Card.jsx'
import ErrorBanner from '../components/ErrorBanner.jsx'
import { RolesAPI } from '../services/api.js'

const SAMPLE_JD = `We are looking for a Python Backend Developer to join our engineering team. You will design and build REST APIs, work with relational databases, and collaborate using Git-based workflows.

Required: Python, REST API design, SQL.
Preferred: FastAPI, Git, Docker.
2+ years of experience preferred.`

export default function CreateJob() {
  const navigate = useNavigate()
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleAnalyze(e) {
    e.preventDefault()
    if (!title.trim() || !description.trim()) {
      setError('Please enter both a job title and a job description.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const role = await RolesAPI.create(title.trim(), description.trim())
      await RolesAPI.analyze(role.id)
      navigate(`/jobs/${role.id}`)
    } catch (err) {
      setError(err.message)
      setLoading(false)
    }
  }

  return (
    <Layout title="Create Job" breadcrumb="Dashboard">
      <div className="mx-auto max-w-2xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Create a job role</h1>
          <p className="mt-1 text-sm text-slate-500">
            The JD Analyzer Agent will read this description and extract structured requirements automatically.
          </p>
        </div>

        <ErrorBanner message={error} onDismiss={() => setError('')} />

        <Card className="p-6">
          <form onSubmit={handleAnalyze} className="space-y-5">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Job Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Python Backend Developer"
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="block text-sm font-medium text-slate-700">Job Description</label>
                <button
                  type="button"
                  onClick={() => {
                    setTitle((t) => t || 'Python Backend Developer')
                    setDescription(SAMPLE_JD)
                  }}
                  className="text-xs font-medium text-brand-600 hover:text-brand-700"
                >
                  Use sample JD
                </button>
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={10}
                placeholder="Paste the full job description here…"
                className="w-full resize-none rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Analyzing Job Description…
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" /> Analyze Job Description
                </>
              )}
            </button>
          </form>
        </Card>
      </div>
    </Layout>
  )
}
