import { Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard.jsx'
import CreateJob from './pages/CreateJob.jsx'
import JobDetail from './pages/JobDetail.jsx'
import CandidateIntelligence from './pages/CandidateIntelligence.jsx'
import InterviewIntelligence from './pages/InterviewIntelligence.jsx'
import AuditTrail from './pages/AuditTrail.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/jobs/new" element={<CreateJob />} />
      <Route path="/jobs/:roleId" element={<JobDetail />} />
      <Route path="/candidates/:candidateId" element={<CandidateIntelligence />} />
      <Route path="/candidates/:candidateId/interview/:requirementId" element={<InterviewIntelligence />} />
      <Route path="/audit" element={<AuditTrail />} />
    </Routes>
  )
}
