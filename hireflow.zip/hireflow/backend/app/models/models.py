"""SQLAlchemy ORM models for HireFlow."""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship

from app.database.db import Base


class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    requirements = relationship("Requirement", back_populates="role", cascade="all, delete-orphan")
    candidates = relationship("Candidate", back_populates="role", cascade="all, delete-orphan")


class Requirement(Base):
    __tablename__ = "requirements"

    id = Column(Integer, primary_key=True, index=True)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    skill = Column(String, nullable=False)
    priority = Column(String, nullable=False, default="Medium")  # High / Medium / Low
    type = Column(String, nullable=False, default="Required")  # Required / Preferred
    description = Column(Text, default="")
    evidence_needed = Column(Text, default="")

    role = relationship("Role", back_populates="requirements")
    evidences = relationship("CandidateEvidence", back_populates="requirement", cascade="all, delete-orphan")


class Candidate(Base):
    __tablename__ = "candidates"

    id = Column(Integer, primary_key=True, index=True)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    resume_path = Column(String, default="")
    resume_text = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    role = relationship("Role", back_populates="candidates")
    evidences = relationship("CandidateEvidence", back_populates="candidate", cascade="all, delete-orphan")
    interviews = relationship("Interview", back_populates="candidate", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="candidate", cascade="all, delete-orphan")


class CandidateEvidence(Base):
    __tablename__ = "candidate_evidence"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    requirement_id = Column(Integer, ForeignKey("requirements.id"), nullable=False)
    status = Column(String, nullable=False, default="NOT_FOUND")  # EXPLICIT / UNCLEAR / NOT_FOUND
    evidence_text = Column(Text, default="")
    source_page = Column(String, default="")
    source_section = Column(String, default="")
    confidence = Column(Float, default=0.0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    candidate = relationship("Candidate", back_populates="evidences")
    requirement = relationship("Requirement", back_populates="evidences")


class Interview(Base):
    __tablename__ = "interviews"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    requirement_id = Column(Integer, ForeignKey("requirements.id"), nullable=False)
    question = Column(Text, default="")
    reason = Column(Text, default="")
    answer = Column(Text, default="")
    analysis = Column(Text, default="")
    evidence_status = Column(String, default="PENDING")  # PENDING / EXPLICIT / UNCLEAR / NOT_FOUND
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

    candidate = relationship("Candidate", back_populates="interviews")
    requirement = relationship("Requirement")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=True)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=True)
    agent = Column(String, nullable=False)
    action = Column(String, nullable=False)
    input_text = Column(Text, default="")
    output_text = Column(Text, default="")
    status = Column(String, default="SUCCESS")
    timestamp = Column(DateTime, default=datetime.utcnow)

    candidate = relationship("Candidate", back_populates="audit_logs")
