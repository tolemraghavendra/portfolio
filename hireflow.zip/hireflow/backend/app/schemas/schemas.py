"""Pydantic schemas for request/response validation."""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, ConfigDict


# ---------- Roles ----------
class RoleCreate(BaseModel):
    title: str
    description: str


class RequirementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    skill: str
    priority: str
    type: str
    description: str
    evidence_needed: str


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: str
    created_at: datetime
    requirements: List[RequirementOut] = []


# ---------- Candidates ----------
class CandidateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    role_id: int
    name: str
    email: str
    created_at: datetime


class EvidenceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    requirement_id: int
    requirement_skill: Optional[str] = None
    requirement_priority: Optional[str] = None
    requirement_type: Optional[str] = None
    status: str
    evidence_text: str
    source_page: str
    source_section: str
    confidence: float
    updated_at: datetime


class EvidenceSummary(BaseModel):
    confirmed: int
    needs_validation: int
    not_found: int
    total: int


class CandidateDetailOut(BaseModel):
    candidate: CandidateOut
    role_title: str
    evidence: List[EvidenceOut]
    summary: EvidenceSummary


# ---------- Interview ----------
class ValidateRequest(BaseModel):
    requirement_id: int


class ValidationQuestionOut(BaseModel):
    interview_id: int
    requirement_id: int
    requirement_skill: str
    reason: str
    question: str


class InterviewAnswerRequest(BaseModel):
    interview_id: int
    answer: str


class InterviewAnalysisOut(BaseModel):
    interview_id: int
    requirement_id: int
    requirement_skill: str
    status: str
    evidence: str
    confidence: float
    follow_up_required: bool


# ---------- Audit ----------
class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    agent: str
    action: str
    input_text: str
    output_text: str
    status: str
    timestamp: datetime


# ---------- Dashboard ----------
class DashboardStats(BaseModel):
    total_roles: int
    total_candidates: int
    needs_validation: int
    pending_review: int
    recent_activity: List[AuditLogOut]
