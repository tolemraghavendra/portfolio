"""Helper to record every agent action into the audit_logs table."""
from sqlalchemy.orm import Session
from app.models.models import AuditLog


def log_action(
    db: Session,
    agent: str,
    action: str,
    input_text: str = "",
    output_text: str = "",
    status: str = "SUCCESS",
    candidate_id: int | None = None,
    role_id: int | None = None,
) -> AuditLog:
    entry = AuditLog(
        agent=agent,
        action=action,
        input_text=(input_text or "")[:4000],
        output_text=(output_text or "")[:4000],
        status=status,
        candidate_id=candidate_id,
        role_id=role_id,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
