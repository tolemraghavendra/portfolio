"""
Small heuristic knowledge base used ONLY by Demo Mode so the agentic
pipeline behaves deterministically and sensibly without a live LLM.

Maps a canonical skill name to:
  - direct keywords that count as EXPLICIT evidence if found near an action verb
  - related/adjacent keywords that count as UNCLEAR evidence (suggestive but not conclusive)
"""

ACTION_VERBS = [
    "developed", "built", "implemented", "designed", "created", "used",
    "worked", "wrote", "deployed", "engineered", "led", "managed",
    "maintained", "architected", "integrated", "automated",
]

SKILL_KB = {
    "python": {"direct": ["python"], "related": ["django", "flask", "fastapi", "pandas", "numpy"]},
    "rest api": {"direct": ["rest api", "restful api", "rest apis", "restful"],
                 "related": ["flask", "django", "fastapi", "api", "endpoint", "endpoints", "http"]},
    "sql": {"direct": ["sql", "mysql", "postgresql", "postgres", "sqlite", "database"],
            "related": ["nosql", "mongodb", "data"]},
    "git": {"direct": ["git", "github", "gitlab", "version control"], "related": ["bitbucket"]},
    "fastapi": {"direct": ["fastapi"], "related": ["flask", "django", "python web framework", "api"]},
    "docker": {"direct": ["docker", "containeriz"], "related": ["kubernetes", "k8s", "container"]},
    "javascript": {"direct": ["javascript", "js "], "related": ["typescript", "node", "react", "vue"]},
    "react": {"direct": ["react", "reactjs", "react.js"], "related": ["javascript", "frontend", "redux"]},
    "aws": {"direct": ["aws", "amazon web services", "ec2", "s3", "lambda"], "related": ["cloud", "azure", "gcp"]},
    "machine learning": {"direct": ["machine learning", "ml model", "scikit-learn", "tensorflow", "pytorch"],
                          "related": ["data science", "pandas", "numpy", "ai"]},
    "docker/kubernetes": {"direct": ["kubernetes", "k8s"], "related": ["docker", "container orchestration"]},
    "ci/cd": {"direct": ["ci/cd", "continuous integration", "continuous deployment", "jenkins", "github actions"],
              "related": ["automation", "pipeline"]},
    "html/css": {"direct": ["html", "css"], "related": ["frontend", "bootstrap", "tailwind"]},
    "node.js": {"direct": ["node.js", "nodejs", "node js"], "related": ["javascript", "express"]},
    "communication": {"direct": ["communication", "presented", "presentation"], "related": ["collaborat", "team"]},
    "leadership": {"direct": ["led a team", "team lead", "managed a team", "leadership"],
                   "related": ["mentored", "supervised", "coordinated"]},
}


def lookup(skill: str):
    """Best-effort fuzzy lookup into SKILL_KB by substring match on the skill name."""
    key = skill.lower().strip()
    if key in SKILL_KB:
        return SKILL_KB[key]
    for k, v in SKILL_KB.items():
        if k in key or key in k:
            return v
    # Fallback: treat the skill name itself as the only direct keyword.
    return {"direct": [key], "related": []}
