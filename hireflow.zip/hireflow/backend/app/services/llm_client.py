"""
Thin wrapper around the OpenAI API with an automatic, deterministic
"Demo Mode" fallback.

Demo Mode activates when:
  - DEMO_MODE=true is set in the environment, OR
  - No OPENAI_API_KEY is configured, OR
  - A live call to the API fails for any reason (network, quota, etc.)

This guarantees the app is always demoable, even with no internet access
or API credits, while still using a real LLM whenever one is available.
"""
import json
import os

DEMO_MODE_FORCED = os.getenv("DEMO_MODE", "false").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

_client = None
if not DEMO_MODE_FORCED and OPENAI_API_KEY:
    try:
        from openai import OpenAI
        _client = OpenAI(api_key=OPENAI_API_KEY)
    except Exception:
        _client = None


def is_demo_mode() -> bool:
    return DEMO_MODE_FORCED or _client is None


def call_json(system_prompt: str, user_prompt: str, demo_fallback: dict):
    """
    Call the LLM and expect a JSON object back. If the LLM is unavailable
    or errors out, `demo_fallback` (a plain dict, already computed by the
    caller's deterministic demo logic) is returned instead, and a flag
    marking the response as demo-mode is attached.
    """
    if is_demo_mode():
        result = dict(demo_fallback)
        result["_demo_mode"] = True
        return result

    try:
        response = _client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
            response_format={"type": "json_object"},
        )
        content = response.choices[0].message.content
        result = json.loads(content)
        result["_demo_mode"] = False
        return result
    except Exception as exc:  # noqa: BLE001 - deliberately broad: any failure -> demo fallback
        result = dict(demo_fallback)
        result["_demo_mode"] = True
        result["_fallback_reason"] = str(exc)
        return result
