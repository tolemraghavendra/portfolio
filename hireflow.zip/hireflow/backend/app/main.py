"""HireFlow FastAPI application entrypoint."""
import os
from dotenv import load_dotenv

# Load .env before anything else reads os.getenv (agents/llm_client depend on this).
load_dotenv()

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.database.db import Base, engine
from app.models import models  # noqa: F401 - ensures models are registered before create_all
from app.api import roles, candidates, interviews, audit, dashboard
from app.services.llm_client import is_demo_mode

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="HireFlow API",
    description="Agentic AI Recruitment & Interview Intelligence Platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": f"Unexpected server error: {exc}"})


app.include_router(roles.router)
app.include_router(candidates.router)
app.include_router(interviews.router)
app.include_router(audit.router)
app.include_router(audit.global_router)
app.include_router(dashboard.router)


@app.get("/")
def root():
    return {
        "app": "HireFlow API",
        "status": "running",
        "demo_mode": is_demo_mode(),
        "docs": "/docs",
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "demo_mode": is_demo_mode()}
