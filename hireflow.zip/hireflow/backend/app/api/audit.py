"""Audit trail endpoint."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Candidate, AuditLog
from app.schemas.schemas import AuditLogOut

router = APIRouter(prefix="/api/candidates", tags=["audit"])
global_router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("/{candidate_id}/audit", response_model=list[AuditLogOut])
def get_audit_trail(candidate_id: int, db: Session = Depends(get_db)):
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    return (
        db.query(AuditLog)
        .filter(AuditLog.candidate_id == candidate_id)
        .order_by(AuditLog.timestamp.asc())
        .all()
    )


@global_router.get("", response_model=list[AuditLogOut])
def get_global_audit_trail(db: Session = Depends(get_db)):
    """Every AI agent action across every role and candidate, most recent first."""
    return db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(300).all()
