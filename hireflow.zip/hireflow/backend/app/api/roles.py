"""Role (job) endpoints: create job, analyze job description, list roles/candidates."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Role, Requirement, Candidate
from app.schemas.schemas import RoleCreate, RoleOut, CandidateOut
from app.agents.jd_agent import analyze_job_description
from app.services.audit import log_action

router = APIRouter(prefix="/api/roles", tags=["roles"])


@router.get("", response_model=list[RoleOut])
def list_roles(db: Session = Depends(get_db)):
    return db.query(Role).order_by(Role.created_at.desc()).all()


@router.post("", response_model=RoleOut)
def create_role(payload: RoleCreate, db: Session = Depends(get_db)):
    if not payload.title.strip() or not payload.description.strip():
        raise HTTPException(status_code=400, detail="Job title and description are required.")
    role = Role(title=payload.title.strip(), description=payload.description.strip())
    db.add(role)
    db.commit()
    db.refresh(role)
    log_action(db, agent="System", action="Job role created", input_text=payload.title,
               output_text=f"Role #{role.id} created", role_id=role.id)
    return role


@router.get("/{role_id}", response_model=RoleOut)
def get_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found.")
    return role


@router.post("/{role_id}/analyze", response_model=RoleOut)
def analyze_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found.")

    # Clear any previous requirements so re-analysis is idempotent.
    db.query(Requirement).filter(Requirement.role_id == role_id).delete()
    db.commit()

    try:
        result = analyze_job_description(role.title, role.description)
    except Exception as exc:  # noqa: BLE001
        log_action(db, agent="JD Analyzer", action="Analysis failed", input_text=role.description,
                   output_text=str(exc), status="ERROR", role_id=role_id)
        raise HTTPException(status_code=502, detail=f"AI analysis failed: {exc}")

    requirements = result.get("requirements", [])
    if not requirements:
        raise HTTPException(status_code=422, detail="AI could not extract any requirements from this job description.")

    for req in requirements:
        db.add(Requirement(
            role_id=role_id,
            skill=req.get("skill", "Unknown")[:120],
            priority=req.get("priority", "Medium"),
            type=req.get("type", "Required"),
            description=req.get("description", ""),
            evidence_needed=req.get("evidence_needed", ""),
        ))
    db.commit()

    mode_note = "Demo Mode" if result.get("_demo_mode") else "Live AI"
    log_action(
        db, agent="JD Analyzer", action=f"Extracted {len(requirements)} requirements ({mode_note})",
        input_text=role.description, output_text=str([r["skill"] for r in requirements]),
        role_id=role_id,
    )

    db.refresh(role)
    return role


@router.get("/{role_id}/candidates", response_model=list[CandidateOut])
def list_candidates(role_id: int, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found.")
    return db.query(Candidate).filter(Candidate.role_id == role_id).order_by(Candidate.created_at.desc()).all()
