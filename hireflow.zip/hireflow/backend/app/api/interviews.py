"""Interview / validation endpoints: Agent 4 (Validation) and Agent 5 (Interview)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Candidate, Requirement, Interview, CandidateEvidence
from app.schemas.schemas import (
    ValidateRequest, ValidationQuestionOut, InterviewAnswerRequest, InterviewAnalysisOut,
)
from app.agents.validation_agent import generate_question
from app.agents.interview_agent import analyze_answer
from app.services.audit import log_action

router = APIRouter(prefix="/api/candidates", tags=["interviews"])


@router.post("/{candidate_id}/validate", response_model=ValidationQuestionOut)
def validate_requirement(candidate_id: int, payload: ValidateRequest, db: Session = Depends(get_db)):
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found.")

    requirement = db.query(Requirement).filter(Requirement.id == payload.requirement_id).first()
    if not requirement:
        raise HTTPException(status_code=404, detail="Requirement not found.")

    evidence = (
        db.query(CandidateEvidence)
        .filter(CandidateEvidence.candidate_id == candidate_id, CandidateEvidence.requirement_id == requirement.id)
        .first()
    )
    if not evidence:
        raise HTTPException(status_code=400, detail="No evidence mapping exists yet for this requirement.")
    if evidence.status == "EXPLICIT":
        raise HTTPException(status_code=400, detail="This requirement already has explicit evidence and does not need validation.")

    try:
        result = generate_question(requirement.skill, evidence.status, evidence.evidence_text)
    except Exception as exc:  # noqa: BLE001
        log_action(db, agent="Validation Agent", action="Question generation failed", output_text=str(exc),
                   status="ERROR", candidate_id=candidate_id)
        raise HTTPException(status_code=502, detail=f"Question generation failed: {exc}")

    interview = Interview(
        candidate_id=candidate_id, requirement_id=requirement.id,
        question=result.get("question", ""), reason=result.get("reason", ""),
        evidence_status="PENDING",
    )
    db.add(interview)
    db.commit()
    db.refresh(interview)

    mode_note = "Demo Mode" if result.get("_demo_mode") else "Live AI"
    log_action(
        db, agent="Validation Agent",
        action=f"Generated validation question for {requirement.skill} ({mode_note})",
        input_text=evidence.evidence_text, output_text=result.get("question", ""),
        candidate_id=candidate_id, status="WARNING",
    )

    return ValidationQuestionOut(
        interview_id=interview.id, requirement_id=requirement.id,
        requirement_skill=requirement.skill, reason=result.get("reason", ""),
        question=result.get("question", ""),
    )


@router.post("/{candidate_id}/interview")
def submit_interview_answer(candidate_id: int, payload: InterviewAnswerRequest, db: Session = Depends(get_db)):
    """Store a candidate's answer to a previously generated validation question."""
    interview = (
        db.query(Interview)
        .filter(Interview.id == payload.interview_id, Interview.candidate_id == candidate_id)
        .first()
    )
    if not interview:
        raise HTTPException(status_code=404, detail="Interview question not found for this candidate.")
    if not payload.answer.strip():
        raise HTTPException(status_code=400, detail="Answer cannot be empty.")

    interview.answer = payload.answer.strip()
    db.commit()
    return {"status": "saved", "interview_id": interview.id}


@router.post("/{candidate_id}/interview/analyze", response_model=InterviewAnalysisOut)
def analyze_interview_answer(candidate_id: int, payload: InterviewAnswerRequest, db: Session = Depends(get_db)):
    interview = (
        db.query(Interview)
        .filter(Interview.id == payload.interview_id, Interview.candidate_id == candidate_id)
        .first()
    )
    if not interview:
        raise HTTPException(status_code=404, detail="Interview question not found for this candidate.")

    answer = payload.answer.strip() if payload.answer and payload.answer.strip() else interview.answer
    if not answer or not answer.strip():
        raise HTTPException(status_code=400, detail="Please provide a candidate answer before analyzing.")

    requirement = db.query(Requirement).filter(Requirement.id == interview.requirement_id).first()
    if not requirement:
        raise HTTPException(status_code=404, detail="Associated requirement not found.")

    try:
        result = analyze_answer(requirement.skill, interview.question, answer)
    except Exception as exc:  # noqa: BLE001
        log_action(db, agent="Interview Agent", action="Answer analysis failed", output_text=str(exc),
                   status="ERROR", candidate_id=candidate_id)
        raise HTTPException(status_code=502, detail=f"Answer analysis failed: {exc}")

    interview.answer = answer
    interview.analysis = result.get("evidence", "")
    interview.evidence_status = result.get("status", "UNCLEAR")
    interview.confidence = float(result.get("confidence", 0.0))
    db.commit()

    # Update the candidate_evidence row so the evidence table reflects the new status.
    evidence = (
        db.query(CandidateEvidence)
        .filter(CandidateEvidence.candidate_id == candidate_id, CandidateEvidence.requirement_id == requirement.id)
        .first()
    )
    if evidence:
        old_status = evidence.status
        evidence.status = result.get("status", evidence.status)
        evidence.evidence_text = result.get("evidence", evidence.evidence_text)
        evidence.source_page = "Interview response"
        evidence.confidence = float(result.get("confidence", evidence.confidence))
        db.commit()
        action_text = f"{requirement.skill} evidence updated: {old_status} \u2192 {evidence.status}"
    else:
        action_text = f"{requirement.skill} evidence status: {result.get('status')}"

    mode_note = "Demo Mode" if result.get("_demo_mode") else "Live AI"
    log_action(
        db, agent="Interview Agent", action=f"{action_text} ({mode_note})",
        input_text=answer, output_text=result.get("evidence", ""),
        candidate_id=candidate_id,
        status="SUCCESS" if result.get("status") == "EXPLICIT" else "WARNING",
    )

    return InterviewAnalysisOut(
        interview_id=interview.id, requirement_id=requirement.id, requirement_skill=requirement.skill,
        status=result.get("status", "UNCLEAR"), evidence=result.get("evidence", ""),
        confidence=float(result.get("confidence", 0.0)),
        follow_up_required=bool(result.get("follow_up_required", False)),
    )
