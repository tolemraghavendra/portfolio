"""Dashboard summary endpoint + global audit feed."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Role, Candidate, CandidateEvidence, AuditLog
from app.schemas.schemas import DashboardStats

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/stats", response_model=DashboardStats)
def get_dashboard_stats(db: Session = Depends(get_db)):
    total_roles = db.query(Role).count()
    total_candidates = db.query(Candidate).count()
    needs_validation = db.query(CandidateEvidence).filter(CandidateEvidence.status == "UNCLEAR").count()
    pending_review = db.query(CandidateEvidence).filter(CandidateEvidence.status.in_(["UNCLEAR", "NOT_FOUND"])).count()
    recent_activity = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(8).all()

    return DashboardStats(
        total_roles=total_roles,
        total_candidates=total_candidates,
        needs_validation=needs_validation,
        pending_review=pending_review,
        recent_activity=recent_activity,
    )
