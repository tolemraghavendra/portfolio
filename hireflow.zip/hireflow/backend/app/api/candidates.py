"""Candidate endpoints: resume upload + analysis, candidate detail, evidence."""
import os
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Role, Requirement, Candidate, CandidateEvidence
from app.schemas.schemas import CandidateDetailOut, CandidateOut, EvidenceOut, EvidenceSummary
from app.utils.text_extraction import extract_text
from app.agents.resume_agent import analyze_resume
from app.agents.evidence_agent import map_evidence
from app.services.audit import log_action

router = APIRouter(prefix="/api/candidates", tags=["candidates"])

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}


@router.post("/upload", response_model=CandidateDetailOut)
async def upload_candidate(
    role_id: int = Form(...),
    name: str = Form(...),
    email: str = Form(...),
    resume: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found. Create and analyze a job first.")

    requirements = db.query(Requirement).filter(Requirement.role_id == role_id).all()
    if not requirements:
        raise HTTPException(status_code=400, detail="This job role has no requirements yet. Click 'Analyze Job Description' first.")

    if not name.strip() or not email.strip():
        raise HTTPException(status_code=400, detail="Candidate name and email are required.")

    ext = os.path.splitext(resume.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext}'. Please upload a PDF, DOCX, or TXT resume.")

    contents = await resume.read()
    if not contents:
        raise HTTPException(status_code=400, detail="The uploaded resume file is empty.")

    saved_name = f"{uuid.uuid4().hex}{ext}"
    saved_path = os.path.join(UPLOAD_DIR, saved_name)
    with open(saved_path, "wb") as f:
        f.write(contents)

    try:
        resume_text = extract_text(saved_path)
    except ValueError as exc:
        os.remove(saved_path)
        raise HTTPException(status_code=422, detail=str(exc))

    candidate = Candidate(role_id=role_id, name=name.strip(), email=email.strip(),
                          resume_path=saved_path, resume_text=resume_text)
    db.add(candidate)
    db.commit()
    db.refresh(candidate)

    # Agent 2: Resume Analyzer
    try:
        facts_result = analyze_resume(resume_text)
    except Exception as exc:  # noqa: BLE001
        log_action(db, agent="Resume Analyzer", action="Analysis failed", output_text=str(exc),
                   status="ERROR", candidate_id=candidate.id, role_id=role_id)
        raise HTTPException(status_code=502, detail=f"Resume analysis failed: {exc}")

    mode_note = "Demo Mode" if facts_result.get("_demo_mode") else "Live AI"
    log_action(
        db, agent="Resume Analyzer",
        action=f"Extracted {len(facts_result.get('facts', []))} resume facts ({mode_note})",
        input_text=resume_text[:500], output_text=str(facts_result.get("facts", []))[:1000],
        candidate_id=candidate.id, role_id=role_id,
    )

    # Agent 3: Evidence Mapping (per requirement)
    unclear_or_missing = []
    for req in requirements:
        try:
            mapped = map_evidence(req.skill, resume_text)
        except Exception as exc:  # noqa: BLE001
            mapped = {"status": "NOT_FOUND", "evidence": f"Mapping failed: {exc}", "source": "\u2014", "confidence": 0.0}

        evidence = CandidateEvidence(
            candidate_id=candidate.id,
            requirement_id=req.id,
            status=mapped.get("status", "NOT_FOUND"),
            evidence_text=mapped.get("evidence", ""),
            source_page=mapped.get("source", "\u2014"),
            confidence=float(mapped.get("confidence", 0.0)),
        )
        db.add(evidence)
        if evidence.status in ("UNCLEAR", "NOT_FOUND"):
            unclear_or_missing.append(req.skill)
    db.commit()

    log_action(
        db, agent="Evidence Mapper",
        action=f"Mapped {len(requirements)} requirements" + (
            f" \u2014 needs validation: {', '.join(unclear_or_missing)}" if unclear_or_missing else " \u2014 all explicit"
        ),
        candidate_id=candidate.id, role_id=role_id,
        status="WARNING" if unclear_or_missing else "SUCCESS",
    )

    return _build_candidate_detail(db, candidate)


def _build_candidate_detail(db: Session, candidate: Candidate) -> CandidateDetailOut:
    evidences = (
        db.query(CandidateEvidence)
        .filter(CandidateEvidence.candidate_id == candidate.id)
        .all()
    )
    evidence_out = []
    confirmed = needs_validation = not_found = 0
    for e in evidences:
        req = db.query(Requirement).filter(Requirement.id == e.requirement_id).first()
        evidence_out.append(EvidenceOut(
            id=e.id, requirement_id=e.requirement_id,
            requirement_skill=req.skill if req else None,
            requirement_priority=req.priority if req else None,
            requirement_type=req.type if req else None,
            status=e.status, evidence_text=e.evidence_text, source_page=e.source_page,
            source_section=e.source_section, confidence=e.confidence, updated_at=e.updated_at,
        ))
        if e.status == "EXPLICIT":
            confirmed += 1
        elif e.status == "UNCLEAR":
            needs_validation += 1
        else:
            not_found += 1

    role = db.query(Role).filter(Role.id == candidate.role_id).first()
    return CandidateDetailOut(
        candidate=CandidateOut.model_validate(candidate),
        role_title=role.title if role else "Unknown Role",
        evidence=evidence_out,
        summary=EvidenceSummary(
            confirmed=confirmed, needs_validation=needs_validation,
            not_found=not_found, total=len(evidence_out),
        ),
    )


@router.get("/{candidate_id}", response_model=CandidateDetailOut)
def get_candidate(candidate_id: int, db: Session = Depends(get_db)):
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    return _build_candidate_detail(db, candidate)


@router.get("/{candidate_id}/evidence", response_model=list[EvidenceOut])
def get_evidence(candidate_id: int, db: Session = Depends(get_db)):
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found.")
    return _build_candidate_detail(db, candidate).evidence
