"""Agent 1 - JD Analyzer Agent.

Input: job title + job description text.
Output: structured list of job requirements.
"""
import re
from app.services.llm_client import call_json, is_demo_mode
from app.prompts.prompts import JD_ANALYZER_SYSTEM
from app.services.skill_knowledge import SKILL_KB

CANONICAL_LABELS = {
    "python": "Python", "rest api": "REST API", "sql": "SQL", "git": "Git",
    "fastapi": "FastAPI", "docker": "Docker", "javascript": "JavaScript",
    "react": "React", "aws": "AWS", "machine learning": "Machine Learning",
    "docker/kubernetes": "Kubernetes", "ci/cd": "CI/CD", "html/css": "HTML/CSS",
    "node.js": "Node.js", "communication": "Communication", "leadership": "Leadership",
}


def _demo_extract(job_title: str, job_description: str) -> dict:
    text = job_description.lower()
    found_required = []
    found_preferred = []

    # crude section split on the word "preferred"
    preferred_idx = text.find("preferred")
    required_section = text[:preferred_idx] if preferred_idx != -1 else text
    preferred_section = text[preferred_idx:] if preferred_idx != -1 else ""

    for key, kws in SKILL_KB.items():
        label = CANONICAL_LABELS.get(key, key.title())
        all_kws = kws["direct"] + kws["related"]
        hit_required = any(kw in required_section for kw in all_kws)
        hit_preferred = any(kw in preferred_section for kw in all_kws)
        if hit_required:
            found_required.append(label)
        elif hit_preferred:
            found_preferred.append(label)

    # de-dup preserving order, cap sizes sensibly
    found_required = list(dict.fromkeys(found_required))[:6]
    found_preferred = [s for s in dict.fromkeys(found_preferred) if s not in found_required][:4]

    if not found_required and not found_preferred:
        # Last-resort fallback so the demo never returns an empty table.
        found_required = ["Python", "SQL"]
        found_preferred = ["Git"]

    requirements = []
    for skill in found_required:
        requirements.append({
            "skill": skill, "type": "Required", "priority": "High",
            "description": f"The role requires hands-on, demonstrable experience with {skill}.",
            "evidence_needed": f"Resume or interview evidence of building something real with {skill}.",
        })
    for skill in found_preferred:
        requirements.append({
            "skill": skill, "type": "Preferred", "priority": "Medium",
            "description": f"{skill} experience is a plus but not mandatory for this role.",
            "evidence_needed": f"Any mention of {skill} in projects or work history.",
        })

    # Experience / education requirements, extracted with light regex.
    exp_match = re.search(r"(\d+)\s*\+?\s*years?", text)
    if exp_match:
        years = exp_match.group(1)
        requirements.append({
            "skill": f"{years}+ years experience", "type": "Required", "priority": "High",
            "description": f"Candidate should have at least {years} years of relevant experience.",
            "evidence_needed": "Work history duration in resume.",
        })
    if "bachelor" in text or "b.tech" in text or "degree" in text:
        requirements.append({
            "skill": "Bachelor's Degree", "type": "Preferred", "priority": "Low",
            "description": "A relevant bachelor's degree is preferred for this role.",
            "evidence_needed": "Education section of resume.",
        })

    return {"requirements": requirements}


def analyze_job_description(job_title: str, job_description: str) -> dict:
    demo_fallback = _demo_extract(job_title, job_description)
    user_prompt = f"Job Title: {job_title}\n\nJob Description:\n{job_description}"
    result = call_json(JD_ANALYZER_SYSTEM, user_prompt, demo_fallback)
    if "requirements" not in result or not result["requirements"]:
        result = dict(demo_fallback)
        result["_demo_mode"] = is_demo_mode()
    return result
