"""Agent 3 - Evidence Mapping Agent.

Compares a single job requirement against the candidate's resume text and
returns an EXPLICIT / UNCLEAR / NOT_FOUND verdict with supporting evidence.
"""
import re
from app.services.llm_client import call_json
from app.prompts.prompts import EVIDENCE_MAPPER_SYSTEM
from app.services.skill_knowledge import lookup, ACTION_VERBS


def _find_page_for_sentence(resume_text: str, sentence: str) -> str:
    matches = list(re.finditer(r"\[Page (\d+)\]", resume_text))
    if not matches:
        return "1"
    idx = resume_text.find(sentence)
    if idx == -1:
        return matches[-1].group(1)
    page = matches[0].group(1)
    for m in matches:
        if m.start() <= idx:
            page = m.group(1)
        else:
            break
    return page


def _sentence_containing(resume_text: str, keyword: str) -> str:
    for sentence in re.split(r"(?<=[.\n])\s+", resume_text):
        if keyword in sentence.lower():
            return sentence.strip()
    return ""


def _demo_map(requirement_skill: str, resume_text: str) -> dict:
    text_lower = resume_text.lower()
    kb = lookup(requirement_skill)

    # 1. Direct keyword present alongside an action verb -> EXPLICIT
    for kw in kb["direct"]:
        if kw in text_lower:
            sentence = _sentence_containing(resume_text, kw)
            has_action = any(v in sentence.lower() for v in ACTION_VERBS) if sentence else False
            page = _find_page_for_sentence(resume_text, sentence) if sentence else "1"
            if has_action or sentence:
                confidence = 0.9 if has_action else 0.78
                status = "EXPLICIT" if has_action else "UNCLEAR"
                return {
                    "status": status,
                    "evidence": sentence or f"Resume mentions '{kw}'.",
                    "source": f"Resume page {page}",
                    "confidence": confidence,
                }

    # 2. Only a related/adjacent keyword present -> UNCLEAR
    for kw in kb["related"]:
        if kw in text_lower:
            sentence = _sentence_containing(resume_text, kw)
            page = _find_page_for_sentence(resume_text, sentence) if sentence else "1"
            return {
                "status": "UNCLEAR",
                "evidence": sentence or f"Resume mentions related technology '{kw}', but not {requirement_skill} directly.",
                "source": f"Resume page {page}",
                "confidence": 0.55,
            }

    # 3. Nothing found at all -> NOT_FOUND
    return {
        "status": "NOT_FOUND",
        "evidence": "No supporting evidence found in the resume.",
        "source": "\u2014",
        "confidence": 0.15,
    }


def map_evidence(requirement_skill: str, resume_text: str) -> dict:
    demo_fallback = _demo_map(requirement_skill, resume_text)
    user_prompt = f"Job Requirement: {requirement_skill}\n\nResume Text:\n{resume_text}"
    result = call_json(EVIDENCE_MAPPER_SYSTEM, user_prompt, demo_fallback)
    if result.get("status") not in ("EXPLICIT", "UNCLEAR", "NOT_FOUND"):
        result = demo_fallback
    return result
