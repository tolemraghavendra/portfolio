"""Agent 4 - Validation Agent.

When evidence status is UNCLEAR or NOT_FOUND, generate a targeted
interview question that would resolve the ambiguity.
"""
from app.services.llm_client import call_json
from app.prompts.prompts import VALIDATION_AGENT_SYSTEM


def _demo_question(requirement_skill: str, status: str, evidence_text: str) -> dict:
    skill = requirement_skill
    if status == "UNCLEAR":
        reason = (
            f"The resume includes evidence that is related to {skill} but does not "
            f"explicitly confirm it: \"{evidence_text}\""
        )
        question = (
            f"Can you describe a specific project where you used {skill}? "
            f"What exactly did you build or implement, and what was your role?"
        )
    else:
        reason = f"The resume contains no evidence at all for {skill}."
        question = (
            f"This role requires {skill}. Have you worked with it in any project, course, "
            f"or job? If so, please describe a concrete example, including what you built."
        )
    return {"reason": reason, "question": question}


def generate_question(requirement_skill: str, status: str, evidence_text: str) -> dict:
    demo_fallback = _demo_question(requirement_skill, status, evidence_text)
    user_prompt = (
        f"Requirement: {requirement_skill}\nEvidence status: {status}\n"
        f"Current evidence: {evidence_text}"
    )
    result = call_json(VALIDATION_AGENT_SYSTEM, user_prompt, demo_fallback)
    if "question" not in result or not result["question"]:
        result = demo_fallback
    return result
