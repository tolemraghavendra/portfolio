"""Agent 5 - Interview Agent.

Analyzes a candidate's answer to a validation question and decides whether
it now provides sufficient evidence for the requirement.
"""
import re
from app.services.llm_client import call_json
from app.prompts.prompts import INTERVIEW_AGENT_SYSTEM
from app.services.skill_knowledge import lookup, ACTION_VERBS

# Signals that suggest a concrete, technically specific answer.
SPECIFICITY_MARKERS = [
    "get", "post", "put", "delete", "patch", "endpoint", "endpoints",
    "class", "function", "table", "query", "commit", "branch", "pull request",
    "docker", "container", "pipeline", "model", "dataset", "api",
]


def _demo_analyze(requirement_skill: str, question: str, answer: str) -> dict:
    answer_lower = answer.lower()
    kb = lookup(requirement_skill)
    word_count = len(answer.split())

    mentions_skill = any(kw in answer_lower for kw in kb["direct"] + kb["related"])
    has_action = any(v in answer_lower for v in ACTION_VERBS)
    has_specificity = any(m in answer_lower for m in SPECIFICITY_MARKERS)
    has_numbers = bool(re.search(r"\d", answer))

    if not answer.strip() or word_count < 4:
        return {
            "status": "NOT_FOUND",
            "evidence": "The candidate did not provide a substantive answer.",
            "confidence": 0.1,
            "follow_up_required": True,
        }

    if mentions_skill and (has_action or has_specificity) and word_count >= 8:
        confidence = 0.94 if (has_specificity and has_numbers) else 0.85
        return {
            "status": "EXPLICIT",
            "evidence": answer.strip()[:280],
            "confidence": confidence,
            "follow_up_required": False,
        }

    if mentions_skill or has_action:
        return {
            "status": "UNCLEAR",
            "evidence": answer.strip()[:280],
            "confidence": 0.55,
            "follow_up_required": True,
        }

    return {
        "status": "NOT_FOUND",
        "evidence": "The answer did not address the requirement with concrete detail.",
        "confidence": 0.2,
        "follow_up_required": True,
    }


def analyze_answer(requirement_skill: str, question: str, answer: str) -> dict:
    demo_fallback = _demo_analyze(requirement_skill, question, answer)
    user_prompt = (
        f"Requirement: {requirement_skill}\nQuestion asked: {question}\n"
        f"Candidate answer: {answer}"
    )
    result = call_json(INTERVIEW_AGENT_SYSTEM, user_prompt, demo_fallback)
    if result.get("status") not in ("EXPLICIT", "UNCLEAR", "NOT_FOUND"):
        result = demo_fallback
    return result
