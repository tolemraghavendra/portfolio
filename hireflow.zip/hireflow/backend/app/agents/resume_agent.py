"""Agent 2 - Resume Analyzer Agent.

Input: candidate resume text.
Output: factual candidate evidence facts (never invented, never inferring
protected attributes). Source page is provided where possible.
"""
import re
from app.services.llm_client import call_json
from app.prompts.prompts import RESUME_ANALYZER_SYSTEM


def _split_pages(resume_text: str):
    """Return list of (page_label, page_text) using [Page N] markers when present."""
    matches = list(re.finditer(r"\[Page (\d+)\]", resume_text))
    if not matches:
        return [("1", resume_text)]
    pages = []
    for i, m in enumerate(matches):
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(resume_text)
        pages.append((m.group(1), resume_text[start:end].strip()))
    return pages


def _demo_extract(resume_text: str) -> dict:
    pages = _split_pages(resume_text)
    facts = []
    for page_label, page_text in pages:
        sentences = re.split(r"(?<=[.\n])\s+", page_text)
        for sentence in sentences:
            s = sentence.strip()
            if len(s) > 15:
                facts.append({"claim": s[:220], "page": page_label})
    return {"facts": facts[:60]}


def analyze_resume(resume_text: str) -> dict:
    demo_fallback = _demo_extract(resume_text)
    result = call_json(RESUME_ANALYZER_SYSTEM, resume_text, demo_fallback)
    if "facts" not in result:
        result = demo_fallback
    return result
