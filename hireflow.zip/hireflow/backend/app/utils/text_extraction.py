"""Extract plain text from uploaded resumes (PDF, DOCX, TXT)."""
import os


def extract_text(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        return _extract_pdf(file_path)
    elif ext == ".docx":
        return _extract_docx(file_path)
    elif ext == ".txt":
        return _extract_txt(file_path)
    else:
        raise ValueError(f"Unsupported resume format: {ext}. Supported: .pdf, .docx, .txt")


def _extract_pdf(file_path: str) -> str:
    from pypdf import PdfReader

    reader = PdfReader(file_path)
    pages = []
    for i, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        pages.append(f"[Page {i}]\n{text.strip()}")
    full_text = "\n\n".join(pages).strip()
    if not full_text:
        raise ValueError("Could not extract any text from this PDF. It may be a scanned image.")
    return full_text


def _extract_docx(file_path: str) -> str:
    import docx

    doc = docx.Document(file_path)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    full_text = "\n".join(paragraphs).strip()
    if not full_text:
        raise ValueError("Could not extract any text from this DOCX file.")
    return full_text


def _extract_txt(file_path: str) -> str:
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read().strip()
    if not text:
        raise ValueError("The uploaded TXT resume is empty.")
    return text
